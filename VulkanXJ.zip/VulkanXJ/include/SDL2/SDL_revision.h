/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-release-2.30.3-0-gfb1497566 (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-release-2.30.3-0-gfb1497566"
#endif
